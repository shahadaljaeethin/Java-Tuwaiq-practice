package com.example.Rewaya;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RewayaApplication {

	public static void main(String[] args) {
		SpringApplication.run(RewayaApplication.class, args);
	}

}
