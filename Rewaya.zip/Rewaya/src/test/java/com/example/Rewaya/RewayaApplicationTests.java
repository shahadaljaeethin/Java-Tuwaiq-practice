package com.example.Rewaya;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RewayaApplicationTests {

	@Test
	void contextLoads() {
	}

}
